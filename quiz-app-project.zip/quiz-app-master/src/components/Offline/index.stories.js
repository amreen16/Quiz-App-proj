import OfflineComponent from './index';

export default {
  title: 'Components/Offline',
  component: OfflineComponent,
};

export const Offline = {};
