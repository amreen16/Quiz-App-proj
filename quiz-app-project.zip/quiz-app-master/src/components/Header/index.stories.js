import HeaderComponent from './index';

export default {
  title: 'Components/Header',
  component: HeaderComponent,
};

export const Header = {};
