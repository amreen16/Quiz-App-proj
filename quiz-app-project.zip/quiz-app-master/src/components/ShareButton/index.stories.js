import ShareButtonComponent from './index';

export default {
  title: 'Components/ShareButton',
  component: ShareButtonComponent,
};

export const ShareButton = {};
